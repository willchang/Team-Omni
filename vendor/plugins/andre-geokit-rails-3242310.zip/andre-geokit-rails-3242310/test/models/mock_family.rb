class MockFamily < ActiveRecord::Base
  belongs_to :mock_house
end