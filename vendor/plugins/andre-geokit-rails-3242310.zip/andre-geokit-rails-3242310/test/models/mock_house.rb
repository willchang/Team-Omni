class MockHouse < ActiveRecord::Base
  acts_as_mappable
end